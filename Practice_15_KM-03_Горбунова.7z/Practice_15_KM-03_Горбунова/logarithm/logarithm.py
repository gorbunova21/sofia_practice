'''
Logarithm module
'''
import math
def log(a,b):
    return round(math.log(b,a),3)
def lg(b):
    return round(math.log(b,10),3)
def ln(b):
    return round(math.log(b),3)