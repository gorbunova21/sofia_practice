import factorial.factorial
import exp_root.exponentiation
import exp_root.root
import logarithm.logarithm
from factorial.factorial import fact
from exp_root.exponentiation import exp2, exp3
from exp_root.root import root2, root3
from logarithm.logarithm import log, lg, ln
print('Умовні позначення функцій:')
print('f-функція обчислення факторіала,')
print('log-функція обчислення логарифма,')
print('lg-функція обчислення логарифма десяткового,')
print('ln-функція обчислення логарифма натурального,')
print('**2-функція піднесення до квадрату,')
print('**3-функція піднесення до кубу,')
print('r2-функція обчислення креня квадратного,')
print('r3-функція обчислення креня кубічного.')
while True:
    answer = input('Оберіть функцію, яку хочете викликати (введіть умовне позначення обраної функції): ')
    if answer == "f" or answer == "log" or answer == "ln" or answer == "lg" or answer == "**2" or answer == "**3" or answer == "r2" or answer == "r3":
        break
    else:
        print("Помилка. Вводити можна лише назви зазначених функцій!")
def number():
    while True:
        try:
            n=float(input('Введіть число: '))
            return n
        except  ValueError:
            print('Помилка. Вводити можна лише число.')
            continue
def pos_number():
    while True:
        try:
            n=float(input('Введіть додатнє число: '))
            if n>0:
                return n
            else:
                print('Помилка. Вводити можна лише 1 додатнє число.')
                continue
        except ValueError:
            print('Помилка. Вводити можна лише 1 додатнє число.')
            continue
if answer=='f':
    print('Ви обрали функцію, що обчислює факторіал числа.')
    while True:
        try:
            n = int(input('Введіть натуральне число: '))
            if n >= 0:
                break
            else:
                print('Помилка. Вводити можна лише 1 натуральне число.')
                continue
        except ValueError:
            print('Помилка. Вводити можна лише 1 натуральне число.')
            continue
    print('Результат:',fact(n))
elif answer=='**2':
    print('Ви обрали функцію, що підносить число до квадрату.')
    n=number()
    print('Результат:',exp2(n))
elif answer=='**3':
    print('Ви обрали функцію, що підносить число до кубу.')
    n=number()
    print('Результат:',exp3(n))
elif answer=='r2':
    print('Ви обрали функцію, що знаходить квадратний корінь з числа.')
    n=pos_number()
    print('Результат:',root2(n))
elif answer=='r3':
    print('Ви обрали функцію, що знаходить кубічний корінь з числа.')
    n=number()
    print('Результат:',root3(n))
elif answer=='log':
    print('Ви обрали функцію, що обчислює логарифм числа.')
    while True:
        try:
            a = float(input('Введіть основу логарифма (додатнє число не рівне 1): '))
            if a > 0 and a!=1:
                break
            else:
                print('Помилка. Вводити можна лише додатнє число не рівне 1.')
                continue
        except ValueError:
            print('Помилка. Вводити можна лише додатнє число не рівне 1.')
            continue
    b=pos_number()
    print('Результат:',log(a,b))
elif answer=='lg':
    print('Ви обрали функцію, що обчислює логарифм числа з основою 10.')
    b=pos_number()
    print('Результат:',lg(b))
elif answer=='ln':
    print('Ви обрали функцію, що обчислює натуральний логарифм числа.')
    b=pos_number()
    print('Результат:',ln(b))

if __name__ == 'main':
    main()

