'''
Exponentiation module
'''
def exp2(n):
    return round(n**2,3)
def exp3(n):
    return round(n**3,3)