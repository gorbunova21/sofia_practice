'''
Root module
'''
def root2(n):
    return round(n**(1/2),3)
def root3(n):
    return round(n ** (1 / 3),3)
